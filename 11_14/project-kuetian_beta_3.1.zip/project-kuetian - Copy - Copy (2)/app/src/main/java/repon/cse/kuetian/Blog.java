package repon.cse.kuetian;

import android.app.Application;

public class Blog extends Application {

}
